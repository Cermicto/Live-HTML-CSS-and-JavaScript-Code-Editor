const htmlFormatted = `<div id="circleContainer">
  <div id="circleFrame">
    <div id="circle1" class="circle"></div>
    <div id="circle2" class="circle"></div>
    <div id="circle3" class="circle"></div>
    <div id="circle4" class="circle"></div>
    <div id="circle5" class="circle"></div>
    <div id="circle6" class="circle"></div>
    <div id="circle7" class="circle"></div>
    <div id="circle8" class="circle"></div>
    <div id="circle9" class="circle"></div>
    <div id="circle10" class="circle"></div>
    <div id="circle11" class="circle"></div>
  </div>
</div>

<div id="circleContainer2">
  <div id="circleFrame2">
    <div id="circle1" class="circle2"></div>
    <div id="circle2" class="circle2"></div>
    <div id="circle3" class="circle2"></div>
    <div id="circle4" class="circle2"></div>
    <div id="circle5" class="circle2"></div>
    <div id="circle6" class="circle2"></div>
    <div id="circle7" class="circle2"></div>
    <div id="circle8" class="circle2"></div>
    <div id="circle9" class="circle2"></div>
    <div id="circle10" class="circle2"></div>
    <div id="circle11" class="circle2"></div>
  </div>
</div>

<div id="text">
  <span id="title">
    Animated Logo
  </span>

  <span id="subtitle">
    <em>Built with HTML and CSS</em>
  </span>
</div>`